const list = document.querySelector('.list-group');
const paragraph1 = document.querySelector('.lead');

// list.insertAdjacentElement('beforebegin', paragraph1);
// list.insertAdjacentElement('afterbegin', paragraph1);
// list.insertAdjacentElement('beforeend', paragraph1);
// list.insertAdjacentElement('afterend', paragraph1);
