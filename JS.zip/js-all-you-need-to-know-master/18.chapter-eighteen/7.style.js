const title = document.querySelector('.title');

// multiple style
title.style.cssText = `padding: 30px; box-shadow: 0 0 10px #000`;

// single style
title.style.color = 'red';
