// Comparison Operator

var num1 = 15;
var num2 = 20;

console.log(num1 == num2);
console.log(num1 != num2);

console.log(num1 > num2);
console.log(num1 >= num2);

console.log(num1 < num2);
console.log(num1 <= num2);

// === and !== check data type also
var num3 = '10';
var num4 = 10;

console.log(num3 == num4);
console.log(num3 === num4);
console.log(num3 != num4);
console.log(num3 !== num4);
