/*
Operator -> 
1)Arithmetic Operator {+,-,*,/,%,++,--}
2)Assignment Operator {=,+=,-=,*=,/=,%=}
3)Logical Operator {&&,||,!}
4)Comparison Operator {==,===,!=,!==,<,<=,>,>=} -> Return a Boolean
5)Ternary Operator (Condition ? true : false)
*/
