// Boolean holo hoyto true return korbe nahole false return korbe... Muloto logic niye kaj korar somoy etar proyojon hoy. true return korle ekta kaj hobe false retunr korle arekta kaj hobe. true/false er data type holo boolean

if (true) {
  console.log('true hole eta hobe');
} else {
  console.log('true na hole eta hobe');
}
