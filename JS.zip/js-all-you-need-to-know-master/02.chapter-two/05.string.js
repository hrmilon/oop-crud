var str1 = 'String';
var str2 = String(99.99);

console.log(str1);
console.log(str2);
