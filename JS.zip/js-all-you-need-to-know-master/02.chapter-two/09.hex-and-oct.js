var hex = 0xff;

console.log(hex);

var oct = 0756;

console.log(oct);
