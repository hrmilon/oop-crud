console.log(Math.E);
console.log(Math.PI);

console.log(Math.floor(4.56));
console.log(Math.ceil(4.46));

console.log(Math.round(4.56));
console.log(Math.round(4.46));

console.log(Math.max(100, 200, 300));
console.log(Math.min(100, 200, 300));

console.log(Math.sqrt(81));

console.log(Math.random());
