// Assignment Operator
var number1 = 50;
var number2 = 10;

number1 += number2; // number1 = number1 + number2
console.log(number1);

number1 -= number2; // number1 = number1 - number2
console.log(number1);

number1 *= number2; // number1 = number1 * number2
console.log(number1);

number1 /= number2; // number1 = number1 / number2
console.log(number1);

number1 %= number2; // number1 = number1 % number2
console.log(number1);
