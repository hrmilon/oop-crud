// Data Type =>  (i. Primitive Data Type) (ii. Object Data Type)

//  Primitive data type holo javascript er nijer toiri data type Ex: Number, String, Boolean, undefined, null, NaN (jegulo javascript amaderke diyeche)

// Object data type holo primitive data type ke use kore amader banano data type Ex: Array, Object, Function
