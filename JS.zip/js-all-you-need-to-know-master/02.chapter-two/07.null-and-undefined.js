var a;
var b = null;

console.log(a);
console.log(b);
