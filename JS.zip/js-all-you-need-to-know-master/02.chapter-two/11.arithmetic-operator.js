// Arithmetic Operator
var num1 = 25;
var num2 = 10;
var num3 = 40;
var num4 = 40;

console.log(num1 + num2);
console.log(num1 - num2);
console.log(num1 / num2);
console.log(num1 * num2);
console.log(num1 % num2);

console.log(++num1);
console.log(num2++);
console.log(num2);

console.log(--num4);
console.log(num3--);
console.log(num3);
