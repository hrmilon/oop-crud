console.log('Bismillahir Rahmanir Rahim');
console.log('Allah has 99 names');

console.log(99);
console.log(99.99);

console.log('My Favourite Num is ' + 99);

console.log(99 + 99);

console.log('9' + 9);
