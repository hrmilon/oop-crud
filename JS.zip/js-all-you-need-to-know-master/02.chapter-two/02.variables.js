var firstName = 'Faysal';
var age = 18;

console.log(firstName);
console.log(age);

console.log('My Name is ' + firstName);
console.log('My age is ' + age);
