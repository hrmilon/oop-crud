var num = 99.99;

console.log(num);
console.log(Number.parseFloat(num));
console.log(Number.parseInt(num));

console.log(Number('88'));
