// Falthy values => false, 0, '', null, undefined , NaN -> egula by default false return kore egula baade baki shb javascript e true return kore

console.log(Boolean(false));
console.log(Boolean(true));

console.log(Boolean(0));
console.log(Boolean(1));

console.log(Boolean(''));
console.log(Boolean('0'));

console.log(Boolean(null));
console.log(Boolean(undefined));
console.log(Boolean(NaN));

// Echarao amra agei jenechi String(), Number(), Boolean() egula diye data type change korte pari
