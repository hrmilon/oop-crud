var friends = ['faysal', 'ahamed', 'chowdhury'];
console.log(friends);

console.log(friends[0]);

friends[3] = 'sayed';
console.log(friends);

console.log(friends.length - 1);

console.log(friends[friends.length - 1]);
