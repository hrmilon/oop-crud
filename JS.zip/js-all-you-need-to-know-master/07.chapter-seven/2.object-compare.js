var obj1 = { a: 10, b: 20 };
var obj2 = { a: 10, b: 20 };

console.log(JSON.stringify(obj1) === JSON.stringify(obj2));
