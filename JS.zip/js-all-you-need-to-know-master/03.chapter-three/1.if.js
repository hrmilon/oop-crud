/*
if(condition == true){
    code...
}
*/

var num1 = 50;
var num2 = 60;

if (num1 <= num2) {
  console.log('Num1 is less than Num2');
}

if (num1 % 2 === 0) {
  console.log('জোড় সংখ্যা');
}
