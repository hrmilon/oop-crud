var num1 = 50;
var num2 = 60;

if (num1 === num2) {
  console.log('Number 1 and Number 2 are equal');
} else {
  console.log('Number 1 and Number 2 are not equal');
}

if (num1 % 2 === 0) {
  console.log('জোড় সংখ্যা');
} else {
  console.log('বিজোড় সংখ্যা');
}
