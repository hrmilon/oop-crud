var num = 20;

var result = num % 2 === 0 ? `${num} is even number` : `${num} is odd number`;

console.log(result);
