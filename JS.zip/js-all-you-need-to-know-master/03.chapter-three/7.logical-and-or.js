var firstName = '';
var fullName = firstName || 'First Name is Not Defined';
console.log(fullName);

var isOk = true;
result = isOk && 'All IS Okay';
console.log(result);
