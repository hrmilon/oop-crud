var rollNo = 3;

switch (rollNo) {
  case 1:
    console.log('Roll 1 Faysal');
    break;
  case 2:
    console.log('Roll 2 Ahamed');
    break;
  case 3:
    console.log('Roll 3 Fahim');
    break;
  default:
    console.log('No One');
}
