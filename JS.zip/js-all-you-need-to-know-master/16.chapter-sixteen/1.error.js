// error
let number = 10;

if (number > 5) {
  throw new Error('number is greater than 5');
}
