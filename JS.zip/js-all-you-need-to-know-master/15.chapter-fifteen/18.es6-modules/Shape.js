class Shape {
  draw() {
    return 'Width is ' + this.width + ' And ' + 'Height is ' + this.height;
  }
}

export default Shape; // export
