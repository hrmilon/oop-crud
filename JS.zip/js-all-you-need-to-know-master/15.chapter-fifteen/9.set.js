// Set
let arr = [1, 2, 3];

let set = new Set(arr);
set.add(4);
set.add(5);
set.add(1);
console.log(set);

// Set Methods => add,clear,delete,size,keys,values,entries,has
