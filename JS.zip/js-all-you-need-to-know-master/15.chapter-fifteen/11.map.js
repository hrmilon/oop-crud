// Map
let map = new Map([
  ['a', 10],
  ['b', 20],
]);

map.set('c', 30);

console.log(map);

// Map Methods => set,clear,delete,keys,values,entries,has,get
