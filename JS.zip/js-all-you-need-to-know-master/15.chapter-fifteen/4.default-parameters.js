function myName(name = 'Faysal') {
  return `My name is ${name}`;
}

console.log(myName());
