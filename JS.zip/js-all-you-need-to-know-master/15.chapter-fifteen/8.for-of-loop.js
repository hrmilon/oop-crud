// Array
const arr = [1, 2, 3];

for (let value of arr) {
  console.log(value);
}

// String
for (let value of 'Faysal') {
  console.log(value);
}
