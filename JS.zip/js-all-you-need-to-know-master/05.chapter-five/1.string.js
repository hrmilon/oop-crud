var str1 = 'something';
console.log(str1);

var str2 = String(10);
console.log(str2);

var n = 10;
console.log(n);

var str3 = n.toString();
console.log(str3);

// String Notation
var str4 = 'What\'s up "man"?';
console.log(str4);
console.log('This is a \nnew line');
console.log('This is \t Tab');

// String Comparison
console.log('z' > 'Z');
console.log('z' > 'a');
// z>>>>>>a>>>>>Z>>>>>A
