// Concat
var a = 'I';
var b = ' am';
var c = ' Faysal';
var d = a.concat(b, c);
console.log(d);

// substr
var e = d.substr(5, 4);
console.log(e);

// charAt
var f = d.charAt(5);
console.log(f);

// startsWith,endsWith
console.log(d.startsWith('I'));
console.log(d.endsWith('Faysal'));

// upperCase(),lowerCase
console.log('hi'.toUpperCase());
console.log('HI'.toLowerCase());

// Trim()
console.log('    hi'.trim());

// split
console.log(d.split(' '));

// length
var name = 'Faysal';
console.log(name.length);
