var add = function (a, b) {
  return a + b;
};

console.log(add(10, 20));

var another = add;
console.log(another(5, 10));
