function add() {
  var a = 10;
  var b = 20;
  var c = a + b;
  return c;
}
console.log(add());
console.log(add());
