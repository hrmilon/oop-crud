var num2 = 2;
while (num2 < 2) {
  console.log(num2);
  num2++;
}

var num2 = 2;
do {
  console.log(num2);
  num2++;
} while (num2 < 2);
