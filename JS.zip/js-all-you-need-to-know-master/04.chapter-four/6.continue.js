for (var i = 1; i <= 10; i++) {
  if (i <= 3) {
    continue;
  } else {
    console.log(i);
  }
}
